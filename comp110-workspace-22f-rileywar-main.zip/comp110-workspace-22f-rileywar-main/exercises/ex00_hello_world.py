"""My first program for COMP110."""

__author__ = "730579921"
print("Hello, world. How's it Going?")